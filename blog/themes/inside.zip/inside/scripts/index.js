require('../lib/config')(hexo);
require('../lib/helper')(hexo);
require('../lib/generator')(hexo);
require('../lib/filter')(hexo);
require('../lib/tag')(hexo);
require('../lib/theme-processor')(hexo);
