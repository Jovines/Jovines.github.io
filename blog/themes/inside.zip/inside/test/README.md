# hexo-theme-inside test case

## Start

Inside the theme folder and run:

```bash
npm install
```

Then run the test:

```bash
npm test
```
