'use strict';

describe('utils', function () {
  require('./rest');
  require('./parseConfig');
});
