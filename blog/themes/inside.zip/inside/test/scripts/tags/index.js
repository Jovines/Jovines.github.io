'use strict';

describe('Tags', function () {
  require('./canvas');
  require('./gist');
});
